package expo.modules.media3feed

import android.content.Context
import android.util.Log
import android.view.Surface
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class FeedItemSpec(
    val id: String,
    val uri: String,
    val isHls: Boolean,
)

/**
 * The event surface this controller emits toward JS. The Fabric view forwards
 * these as onXxx props; the module also emits a couple as device events for
 * anything listening outside a specific view instance (telemetry mainly).
 */
interface PreloadEvents {
    fun onFirstFrame(itemId: String)
    fun onBufferingChange(itemId: String, isBuffering: Boolean)
    fun onPlaybackError(itemId: String, message: String)
    fun onProgress(itemId: String, positionMs: Long, durationMs: Long)
    fun onCompleted(itemId: String)
}

/**
 * Owns a small, fixed pool of ExoPlayer instances and a wider, cheaper byte
 * prefetch queue. This is the load-bearing design decision of the whole
 * module: decoder warm-up (expensive, hardware-limited, 3-4 instances max)
 * is fully decoupled from surface attach (free, exactly one at a time in a
 * paged feed).
 *
 * Player instances are created once and never torn down for the life of the
 * controller — rebinding a MediaSource on an existing player is what's cheap;
 * constructing a new ExoPlayer is what's expensive.
 */
class PreloadController(
    private val context: Context,
    slotCountHint: Int,
    events: PreloadEvents,
) {
    private val tag = "Media3Feed"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Reassignable: the controller is often constructed before the Fabric view
    // finishes mounting, so the real event dispatcher is wired in afterward via
    // Media3FeedModule.OnViewDidUpdateProps rather than captured once here.
    var events: PreloadEvents = events

    private val slotCount = DecoderBudget.playerSlots(slotCountHint)
    private val slots: List<Slot> = List(slotCount) { Slot(buildPlayer(it)) }

    private var queue: List<FeedItemSpec> = emptyList()
    private var currentIndex = 0
    private var activeSurface: Surface? = null
    private var activeItemId: String? = null

    // Byte-ahead prefetch, wider and cheaper than the decoder pool.
    private val prefetchJobs = ConcurrentHashMap<String, Job>()
    var byteAheadDepth: Int = 6

    private inner class Slot(val player: ExoPlayer) {
        var boundItemId: String? = null
        var rank: Int = Int.MAX_VALUE // distance from currentIndex; MAX = unassigned
    }

    private fun buildPlayer(index: Int): ExoPlayer {
        val dsFactory = MediaCache.dataSourceFactory(context)
        val player = ExoPlayer.Builder(context)
            .setMediaSourceFactory(
                androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dsFactory)
            )
            .build()
        player.playWhenReady = false
        player.repeatMode = Player.REPEAT_MODE_OFF
        player.volume = 1f

        player.addListener(object : Player.Listener {
            override fun onRenderedFirstFrame() {
                val id = slots.getOrNull(index)?.boundItemId ?: return
                if (id == activeItemId) events.onFirstFrame(id)
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                val id = slots.getOrNull(index)?.boundItemId ?: return
                events.onBufferingChange(id, isLoading)
            }

            override fun onPlayerError(error: PlaybackException) {
                val id = slots.getOrNull(index)?.boundItemId ?: return
                Log.w(tag, "player[$index] error for $id", error)
                events.onPlaybackError(id, error.errorCodeName)
            }

            override fun onPlaybackStateChanged(state: Int) {
                val id = slots.getOrNull(index)?.boundItemId ?: return
                if (state == Player.STATE_ENDED && id == activeItemId) {
                    events.onCompleted(id)
                }
            }
        })

        return player
    }

    private fun sourceFor(spec: FeedItemSpec): MediaSource {
        val item = MediaItem.Builder().setUri(spec.uri).setMediaId(spec.id).build()
        val dsFactory = MediaCache.dataSourceFactory(context)
        return if (spec.isHls) {
            HlsMediaSource.Factory(dsFactory).createMediaSource(item)
        } else {
            ProgressiveMediaSource.Factory(dsFactory).createMediaSource(item)
        }
    }

    /**
     * Called on every settle (scroll snap) and on queue refresh. Reassigns the
     * fixed decoder pool to the nearest `slotCount` items by rank distance, and
     * kicks off byte-only prefetch for the wider ring beyond that.
     */
    fun setQueue(items: List<FeedItemSpec>, index: Int) {
        queue = items
        currentIndex = index.coerceIn(0, maxOf(items.lastIndex, 0))
        reconcileSlots()
        reconcilePrefetch()
    }

    private fun reconcileSlots() {
        if (queue.isEmpty()) return

        // Target set: current, then alternating +1/-1 out to slotCount items.
        val targetIds = LinkedHashSet<Int>()
        targetIds += currentIndex
        var offset = 1
        while (targetIds.size < slotCount && (currentIndex - offset >= 0 || currentIndex + offset <= queue.lastIndex)) {
            if (currentIndex + offset <= queue.lastIndex) targetIds += currentIndex + offset
            if (targetIds.size >= slotCount) break
            if (currentIndex - offset >= 0) targetIds += currentIndex - offset
            offset++
        }
        val targets = targetIds.mapNotNull { queue.getOrNull(it) }

        val alreadyBound = slots.mapNotNull { it.boundItemId }.toSet()
        val need = targets.filter { it.id !in alreadyBound }
        val freeSlots = slots.filter { it.boundItemId == null || it.boundItemId !in targets.map { t -> t.id } }
            .sortedByDescending { it.rank } // evict the farthest-bound first

        var freeIdx = 0
        for (spec in need) {
            val slot = freeSlots.getOrNull(freeIdx) ?: continue
            freeIdx++
            bind(slot, spec)
        }

        // Update rank bookkeeping for events / eviction ordering next time.
        for (slot in slots) {
            val id = slot.boundItemId ?: continue
            val pos = queue.indexOfFirst { it.id == id }
            slot.rank = if (pos < 0) Int.MAX_VALUE else kotlin.math.abs(pos - currentIndex)
        }
    }

    private fun bind(slot: Slot, spec: FeedItemSpec) {
        // Detach the surface before swapping content on a player that
        // currently owns it — otherwise the old frame flashes briefly.
        if (slot.boundItemId == activeItemId && slot.player.videoSurface != null) {
            slot.player.clearVideoSurface()
        }
        slot.boundItemId = spec.id
        slot.player.setMediaSource(sourceFor(spec), /* resetPosition = */ true)
        slot.player.prepare()
        // Prepared-but-not-attached: MediaCodec is warm, buffer is filling,
        // no Surface, no compositing cost. This is the "instant" in instant-buffer.
    }

    private fun reconcilePrefetch() {
        val depth = byteAheadDepth.coerceAtLeast(slotCount)
        val ring = (currentIndex..minOf(currentIndex + depth, queue.lastIndex)).toList() +
            (maxOf(currentIndex - 1, 0) until currentIndex).toList()
        val wantIds = ring.mapNotNull { queue.getOrNull(it)?.id }.toSet()

        // Cancel prefetch for anything that fell out of range.
        val stale = prefetchJobs.keys - wantIds
        for (id in stale) prefetchJobs.remove(id)?.cancel()

        for (id in wantIds) {
            if (prefetchJobs.containsKey(id)) continue
            val spec = queue.firstOrNull { it.id == id } ?: continue
            // Decoder-pooled items are already warm via prepare(); only
            // byte-prefetch the ring beyond the pool.
            if (slots.any { it.boundItemId == id }) continue
            prefetchJobs[id] = ioScope.launch { prefetchBytes(spec) }
        }
    }

    private suspend fun prefetchBytes(spec: FeedItemSpec) = withContext(Dispatchers.IO) {
        try {
            val dataSpec = androidx.media3.datasource.DataSpec.Builder()
                .setUri(android.net.Uri.parse(spec.uri))
                // First couple seconds only — enough to make the eventual
                // prepare() near-instant without warming a full decode.
                .setLength(if (spec.isHls) androidx.media3.common.C.LENGTH_UNSET.toLong() else 1_500_000L)
                .build()
            val writer = CacheWriter(
                MediaCache.dataSourceFactory(context).createDataSource(),
                dataSpec,
                null,
            ) { _, bytesCached, _ ->
                if (bytesCached > 4_000_000L) throw CancellationSignalReached()
            }
            writer.cache()
        } catch (_: CancellationSignalReached) {
            // Intentional early stop once we've warmed enough of the file.
        } catch (t: Throwable) {
            Log.d(tag, "byte prefetch skipped for ${spec.id}: ${t.message}")
        }
    }

    private class CancellationSignalReached : Exception()

    /** Attaches the render surface to whichever slot owns `itemId` and plays it. */
    fun settle(itemId: String, surface: Surface?) {
        activeItemId = itemId
        val target = slots.firstOrNull { it.boundItemId == itemId }

        for (slot in slots) {
            if (slot !== target && slot.player.videoSurface != null) {
                slot.player.clearVideoSurface()
                slot.player.pause()
            }
        }

        if (target == null) {
            Log.w(tag, "settle($itemId): no warm slot — cold path, expect a stall")
            return
        }

        activeSurface = surface
        if (surface != null) target.player.setVideoSurface(surface)
        target.player.playWhenReady = true
    }

    fun pauseActive() {
        slots.firstOrNull { it.boundItemId == activeItemId }?.player?.playWhenReady = false
    }

    fun seekActiveTo(positionMs: Long) {
        slots.firstOrNull { it.boundItemId == activeItemId }?.player?.seekTo(positionMs)
    }

    /** Poll for progress; called on a low-rate timer from the JS side, not per-frame. */
    fun activeProgress(): Pair<Long, Long>? {
        val p = slots.firstOrNull { it.boundItemId == activeItemId }?.player ?: return null
        return p.currentPosition to p.duration.coerceAtLeast(0)
    }

    /** Called from Activity onStop — decoders are a scarce OS resource. */
    fun suspendAll() {
        for (slot in slots) {
            slot.player.clearVideoSurface()
            slot.player.playWhenReady = false
        }
    }

    fun resumeActive() {
        activeItemId?.let { settle(it, activeSurface) }
    }

    fun release() {
        prefetchJobs.values.forEach { it.cancel() }
        prefetchJobs.clear()
        ioScope.cancel()
        scope.cancel()
        for (slot in slots) {
            runCatching { slot.player.release() }
        }
    }
}
