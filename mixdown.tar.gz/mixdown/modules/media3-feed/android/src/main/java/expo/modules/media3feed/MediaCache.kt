package expo.modules.media3feed

import android.content.Context
import android.media.MediaCodecList
import android.util.Log
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import java.io.File

/**
 * One process-wide SimpleCache. Two instances pointed at the same directory
 * throw at construction, so this must stay a singleton even across activity
 * recreation.
 */
object MediaCache {

    private const val TAG = "Media3Feed"
    private const val DEFAULT_BYTES = 512L * 1024 * 1024

    @Volatile
    private var cache: SimpleCache? = null

    fun get(context: Context, maxBytes: Long = DEFAULT_BYTES): SimpleCache {
        cache?.let { return it }
        return synchronized(this) {
            cache ?: SimpleCache(
                File(context.cacheDir, "media3-feed"),
                LeastRecentlyUsedCacheEvictor(maxBytes),
                StandaloneDatabaseProvider(context)
            ).also { cache = it }
        }
    }

    /**
     * Read-write factory for playback. `setFlags` with IGNORE_CACHE_ON_ERROR
     * means a corrupt cache entry degrades to a network read instead of
     * failing the item.
     */
    fun dataSourceFactory(context: Context): CacheDataSource.Factory {
        val upstream = DefaultHttpDataSource.Factory()
            .setUserAgent("mixdown/1.0 (Android)")
            .setConnectTimeoutMs(8_000)
            .setReadTimeoutMs(8_000)
            .setAllowCrossProtocolRedirects(true)

        return CacheDataSource.Factory()
            .setCache(get(context))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    fun release() {
        synchronized(this) {
            runCatching { cache?.release() }
                .onFailure { Log.w(TAG, "cache release failed", it) }
            cache = null
        }
    }
}

/**
 * How many hardware video decoders this device will actually give us.
 *
 * Exceeding the limit surfaces as MediaCodec.CodecException, or worse, a silent
 * fall back to software decode that destroys both framerate and battery. Every
 * "prefetch 8 videos ahead" design dies here. Midrange Android commonly reports
 * 4-8 for AVC and fewer for HEVC.
 */
object DecoderBudget {

    private const val TAG = "Media3Feed"

    private val probed: Int by lazy { probe() }

    private fun probe(): Int {
        val mimes = listOf("video/avc", "video/hevc")
        var worst = Int.MAX_VALUE

        try {
            val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            for (mime in mimes) {
                val best = infos
                    .filter { !it.isEncoder }
                    .filter { info -> info.supportedTypes.any { it.equals(mime, true) } }
                    .mapNotNull { info ->
                        runCatching { info.getCapabilitiesForType(mime).maxSupportedInstances }
                            .getOrNull()
                    }
                    .filter { it > 0 }
                    .maxOrNull()

                if (best != null) worst = minOf(worst, best)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "decoder probe failed, assuming conservative budget", t)
        }

        if (worst == Int.MAX_VALUE) worst = 4
        Log.i(TAG, "decoder instance budget: $worst")
        return worst
    }

    /**
     * Player slots we are willing to hold warm. One decoder is reserved as
     * headroom for the system (notification previews, another app resuming),
     * and we never exceed four regardless of what the device claims — beyond
     * that the memory cost outweighs the latency win.
     */
    fun playerSlots(requested: Int): Int =
        requested.coerceIn(2, minOf(4, maxOf(2, probed - 1)))

    fun raw(): Int = probed
}
