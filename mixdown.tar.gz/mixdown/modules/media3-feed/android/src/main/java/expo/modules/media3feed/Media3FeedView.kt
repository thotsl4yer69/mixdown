package expo.modules.media3feed

import android.content.Context
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.FrameLayout
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.viewevent.EventDispatcher
import expo.modules.kotlin.views.ExpoView

/**
 * There is exactly one of these per feed screen, absolutely positioned over
 * the list by JS (Reanimated) rather than rendered per row. It must never
 * unmount during a scroll gesture — that is the entire point. Cells in the
 * FlashList are poster images only; this view is the single video surface
 * that gets logically "handed" between queue positions on settle.
 */
class Media3FeedView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {

    private val surfaceView = SurfaceView(context).apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT,
        )
    }

    private var controller: PreloadController? = null
    private var pendingSurface: Surface? = null
    private var pendingSettleItemId: String? = null

    val onFirstFrame by EventDispatcher<Map<String, Any?>>()
    val onBuffering by EventDispatcher<Map<String, Any?>>()
    val onPlaybackError by EventDispatcher<Map<String, Any?>>()
    val onCompleted by EventDispatcher<Map<String, Any?>>()

    init {
        addView(surfaceView)
        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                pendingSurface = holder.surface
                pendingSettleItemId?.let { controller?.settle(it, holder.surface) }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                pendingSurface = null
            }
        })
    }

    fun bind(controller: PreloadController) {
        this.controller = controller
    }

    fun settle(itemId: String) {
        pendingSettleItemId = itemId
        controller?.settle(itemId, pendingSurface)
    }

    fun events(): PreloadEvents = object : PreloadEvents {
        override fun onFirstFrame(itemId: String) {
            onFirstFrame(mapOf("itemId" to itemId))
        }
        override fun onBufferingChange(itemId: String, isBuffering: Boolean) {
            onBuffering(mapOf("itemId" to itemId, "isBuffering" to isBuffering))
        }
        override fun onPlaybackError(itemId: String, message: String) {
            onPlaybackError(mapOf("itemId" to itemId, "message" to message))
        }
        override fun onProgress(itemId: String, positionMs: Long, durationMs: Long) = Unit
        override fun onCompleted(itemId: String) {
            onCompleted(mapOf("itemId" to itemId))
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        // The controller outlives this view (it's owned by the module and can
        // survive a view recreation), so we only drop the surface reference here.
        pendingSurface = null
    }
}
