package expo.modules.media3feed

import android.app.Activity
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.records.Field
import expo.modules.kotlin.records.Record

class FeedItemRecord : Record {
    @Field val id: String = ""
    @Field val uri: String = ""
    @Field val isHls: Boolean = false
}

/**
 * Thin bridge from JS to PreloadController. The controller is created lazily
 * on first setQueue call and lives for the process lifetime of the feed
 * screen — recreating it on every re-render would defeat the entire warm-pool
 * design.
 */
class Media3FeedModule : Module() {

    private var controller: PreloadController? = null
    private var boundView: Media3FeedView? = null

    override fun definition() = ModuleDefinition {
        Name("Media3Feed")

        Events("onCacheStats")

        Function("decoderBudget") {
            DecoderBudget.raw()
        }

        AsyncFunction("setQueue") { items: List<FeedItemRecord>, currentIndex: Int, slotHint: Int ->
            val ctx = appContext.reactContext ?: return@AsyncFunction
            val ctrl = controller ?: PreloadController(
                ctx.applicationContext,
                slotHint,
                boundView?.events() ?: NoopEvents,
            ).also { controller = it }

            ctrl.setQueue(
                items.map { FeedItemSpec(id = it.id, uri = it.uri, isHls = it.isHls) },
                currentIndex,
            )
        }

        AsyncFunction("settle") { itemId: String ->
            controller?.settle(itemId, null) // surface comes from the bound view's own SurfaceHolder
            boundView?.settle(itemId)
        }

        AsyncFunction("pauseActive") {
            controller?.pauseActive()
        }

        AsyncFunction("seekActiveTo") { positionMs: Double ->
            controller?.seekActiveTo(positionMs.toLong())
        }

        AsyncFunction("activeProgress") {
            val (pos, dur) = controller?.activeProgress() ?: (0L to 0L)
            mapOf("positionMs" to pos, "durationMs" to dur)
        }

        AsyncFunction("suspendAll") {
            controller?.suspendAll()
        }

        AsyncFunction("resumeActive") {
            controller?.resumeActive()
        }

        AsyncFunction("release") {
            controller?.release()
            controller = null
        }

        View(Media3FeedView::class) {
            Events("onFirstFrame", "onBuffering", "onPlaybackError", "onCompleted")

            OnViewDidUpdateProps { view ->
                boundView = view
                controller?.let {
                    it.events = view.events()
                    view.bind(it)
                }
            }
        }
    }

    private object NoopEvents : PreloadEvents {
        override fun onFirstFrame(itemId: String) = Unit
        override fun onBufferingChange(itemId: String, isBuffering: Boolean) = Unit
        override fun onPlaybackError(itemId: String, message: String) = Unit
        override fun onProgress(itemId: String, positionMs: Long, durationMs: Long) = Unit
        override fun onCompleted(itemId: String) = Unit
    }
}
